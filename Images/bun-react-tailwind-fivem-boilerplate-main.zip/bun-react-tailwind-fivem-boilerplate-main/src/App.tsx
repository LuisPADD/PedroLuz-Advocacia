import { useEffect, useState } from "react";
import { useNuiEvent } from "./hooks/useNuiEvent";
import { debugData } from "./utils/debugData";
import { fetchNui } from "./utils/fetchNui";
import { useKeyListener } from "./hooks/useKeyListener";
import { isEnvBrowser } from "./utils/misc";

export function App() {
  const [visible, setVisible] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useKeyListener("Escape", () => {
    setVisible(false);
    if(isEnvBrowser()) console.log("Escape key pressed");
  });

  useNuiEvent<{ visibility: boolean }>("setVisible", (data) => {
    setVisible(data.visibility);
  });

  useEffect(() => {
    debugData([
      {
        action: "setVisible",
        data: {
          visibility: true,
        },
      },
    ]);
  }, []);

  async function saveData() {
    if (isSaving) return;
    setIsSaving(true);
    const response = await fetchNui(
      "saveData",
      {
        data: {
          name: "John Doe",
          age: 30,
        },
      },
      {
        success: true,
      },
      1000,
    );
    setIsSaving(false);
    
    if (response.success) {
      console.log("Data saved successfully");
    } else {
      console.log("Failed to save data");
    }
  }

  return (
    <div
      className={[
        "mx-auto flex min-h-screen items-center justify-center p-6",
        "text-neutral-100",
        visible ? "opacity-100" : "opacity-0 pointer-events-none",
      ].join(" ")}
    >
      <div className="w-full max-w-md rounded-xl border border-neutral-800 bg-neutral-900/60 p-6 text-center">
        <p className="text-xs uppercase tracking-[0.3em] text-neutral-500">
          NUI
        </p>
        <h1 className="mt-2 text-2xl font-semibold text-neutral-100">
          Hello, Worlds!
        </h1>
        <p className="mt-2 text-sm text-neutral-400">
          Minimal panel for quick actions
        </p>
        <button
          className={[
            "mt-5 w-full rounded-lg border px-4 py-2 text-sm font-medium transition",
            isSaving
              ? "border-neutral-800 bg-neutral-900 text-neutral-500"
              : "border-neutral-700 bg-neutral-800 text-neutral-100 hover:border-neutral-500 hover:bg-neutral-700",
          ].join(" ")}
          onClick={saveData}
          disabled={isSaving}
        >
          {isSaving ? "Saving..." : "Save Data"}
        </button>
      </div>
    </div>
  );
}
