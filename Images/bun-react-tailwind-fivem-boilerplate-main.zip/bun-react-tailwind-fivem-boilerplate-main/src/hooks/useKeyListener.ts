import { useEffect, useRef } from "react";
import { fetchNui } from "../utils/fetchNui";
import { noop } from "../utils/misc";

type KeyHandlerSignature = (event: KeyboardEvent) => void;

export const useKeyListener = (
  key: string,
  handler: (event: KeyboardEvent) => void,
  action?: string,
) => {
  const savedHandler = useRef<KeyHandlerSignature>(noop);

  useEffect(() => {
    savedHandler.current = handler;
  }, [handler]);

  useEffect(() => {
    const normalizedKey = key.toLowerCase();
    const eventListener = (event: KeyboardEvent) => {
      if (event.key.toLowerCase() !== normalizedKey) return;

      if (savedHandler.current) {
        savedHandler.current(event);
      }

      if (action) {
        void fetchNui(action);
      }
    };

    window.addEventListener("keydown", eventListener);
    return () => window.removeEventListener("keydown", eventListener);
  }, [key, action]);
};
