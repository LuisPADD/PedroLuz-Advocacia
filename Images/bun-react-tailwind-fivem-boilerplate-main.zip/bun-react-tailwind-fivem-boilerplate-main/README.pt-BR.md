# bun-react-tailwind-fivem-boilerplate

## Configuração

Para instalar dependências:

```bash
bun install
```

Para rodar:

```bash
bun run index.ts
```

## Hooks e Utilitários (Passo a Passo)

Este projeto inclui um conjunto pequeno de hooks e utilitários focados em NUI. Eles ajudam sua UI a ouvir eventos do jogo, enviar dados de volta ao cliente e simular eventos durante o desenvolvimento no navegador.

### 1) useNuiEvent

**O que é:** Um hook React que escuta mensagens do `window` vindas do jogo (NUI) e executa seu handler apenas para um `action` específico.

**Por que existe:** No NUI do FiveM, scripts do client se comunicam com a UI via `SendNuiMessage`. Esse hook integra essas mensagens ao React de forma limpa.

**Como usar (passo a passo):**
1. Escolha o `action` que seu script do client vai enviar (ex.: `"setVisible"`).
2. Forneça um handler que recebe o payload `data`.
3. Atualize o estado do componente dentro do handler.

```tsx
import { useState } from "react";
import { useNuiEvent } from "./hooks/useNuiEvent";

export function App() {
  const [visible, setVisible] = useState(false);

  useNuiEvent<{ visibility: boolean }>("setVisible", (data) => {
    setVisible(data.visibility);
  });

  return visible ? <div>Panel</div> : null;
}
```

### 2) useKeyListener

**O que é:** Um hook React que escuta uma tecla específica do teclado e dispara um handler. Opcionalmente, também pode enviar um evento NUI via `fetchNui`.

**Por que existe:** Simplifica atalhos de teclado (como ESC para fechar) e pode notificar o client quando uma tecla é pressionada.

**Como usar (passo a passo):**
1. Escolha a tecla que deseja escutar (ex.: `"Escape"` ou `"e"`).
2. Forneça um handler para executar quando a tecla for pressionada.
3. Opcionalmente, passe um `action` para disparar um callback do client com `fetchNui`.

```tsx
import { useKeyListener } from "./hooks/useKeyListener";

export function App() {
  useKeyListener("Escape", () => {
    console.log("Escape key pressed");
  });

  useKeyListener("e", () => {
    console.log("Interact");
  }, "player:interact");

  return <div>Panel</div>;
}
```

### 3) fetchNui

**O que é:** Uma função helper que envia um POST para os scripts do client usando o endpoint de callback do NUI.

**Por que existe:** Abstrai o `fetch` e o nome do resource, além de suportar mock data no navegador.

**Como usar (passo a passo):**
1. Defina o nome do evento que seu script do client espera.
2. Passe os dados que deseja enviar.
3. Opcionalmente, passe mock data e delay para testes no navegador.

```tsx
import { fetchNui } from "./utils/fetchNui";

async function saveData() {
  const response = await fetchNui(
    "saveData",
    { data: { name: "John Doe", age: 30 } },
    { success: true },
    1000,
  );

  if (response.success) {
    console.log("Saved!");
  }
}
```

### 4) debugData

**O que é:** Um utilitário que simula `SendNuiMessage` disparando mensagens falsas no navegador.

**Por que existe:** Quando você roda a UI em um navegador comum, não há client do jogo para enviar eventos NUI. O `debugData` permite mockar esses eventos durante o desenvolvimento.

**Como usar (passo a passo):**
1. Crie uma lista de eventos com `action` e `data`.
2. Chame `debugData` no mount (geralmente dentro de `useEffect`).
3. O utilitário vai disparar eventos `message` após um pequeno delay.

```tsx
import { useEffect } from "react";
import { debugData } from "./utils/debugData";

useEffect(() => {
  debugData([
    { action: "setVisible", data: { visibility: true } },
  ]);
}, []);
```

## Notas

- `fetchNui` usa mock data apenas quando está rodando em um ambiente de navegador comum.
- `debugData` roda somente em modo de desenvolvimento e no navegador.
