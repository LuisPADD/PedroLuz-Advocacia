# bun-react-tailwind-fivem-boilerplate ([PT-BR](README.pt-BR.md))

## Setup

To install dependencies:

```bash
bun install
```

To run:

```bash
bun run index.ts
```

## Hooks and Utilities (Step by Step)

This project includes a small set of NUI-focused hooks and utilities. They help your UI listen to game events, send data back to the client, and simulate events while developing in a browser.

### 1) useNuiEvent

**What it is:** A React hook that listens to `window` messages from the game (NUI) and runs your handler only for a specific `action`.

**Why it exists:** In FiveM NUI, client scripts communicate with the UI via `SendNuiMessage`. This hook wires those messages into React in a clean way.

**How to use it (step by step):**
1. Pick the `action` string your client script will send (e.g. `"setVisible"`).
2. Provide a handler that receives the `data` payload.
3. Update your component state inside the handler.

```tsx
import { useState } from "react";
import { useNuiEvent } from "./hooks/useNuiEvent";

export function App() {
  const [visible, setVisible] = useState(false);

  useNuiEvent<{ visibility: boolean }>("setVisible", (data) => {
    setVisible(data.visibility);
  });

  return visible ? <div>Panel</div> : null;
}
```

### 2) useKeyListener

**What it is:** A React hook that listens for a specific keyboard key and triggers a handler. Optionally, it can also send an NUI event through `fetchNui`.

**Why it exists:** It simplifies keyboard shortcuts (like ESC to close) and can optionally notify the client scripts when a key is pressed.

**How to use it (step by step):**
1. Choose the key you want to listen for (e.g. `"Escape"` or `"e"`).
2. Provide a handler to run when the key is pressed.
3. Optionally pass an `action` string to send a client callback using `fetchNui`.

```tsx
import { useKeyListener } from "./hooks/useKeyListener";

export function App() {
  useKeyListener("Escape", () => {
    console.log("Escape key pressed");
  });

  useKeyListener("e", () => {
    console.log("Interact");
  }, "player:interact");

  return <div>Panel</div>;
}
```

### 3) fetchNui

**What it is:** A helper function that sends a POST request to the client scripts using the NUI callback endpoint.

**Why it exists:** It abstracts the `fetch` and resource name logic, and supports mock data in the browser.

**How to use it (step by step):**
1. Decide the event name your client script is listening for.
2. Pass any data you want to send.
3. Optionally pass mock data and delay for browser testing.

```tsx
import { fetchNui } from "./utils/fetchNui";

async function saveData() {
  const response = await fetchNui(
    "saveData",
    { data: { name: "John Doe", age: 30 } },
    { success: true },
    1000,
  );

  if (response.success) {
    console.log("Saved!");
  }
}
```

### 4) debugData

**What it is:** A utility that simulates `SendNuiMessage` by dispatching fake messages in the browser.

**Why it exists:** When you run the UI in a normal browser, there is no game client to send NUI events. `debugData` lets you mock those events during development.

**How to use it (step by step):**
1. Create a list of events with `action` and `data`.
2. Call `debugData` on mount (usually inside `useEffect`).
3. The hook will dispatch `message` events after a short delay.

```tsx
import { useEffect } from "react";
import { debugData } from "./utils/debugData";

useEffect(() => {
  debugData([
    { action: "setVisible", data: { visibility: true } },
  ]);
}, []);
```

## Notes

- `fetchNui` uses mock data only when running in a normal browser environment.
- `debugData` only runs in development mode and in the browser.
